//
//  DatabaseManager.m
//  Contacts
//
//  Created by Muralitharan on 10/11/11.
//  Copyright 2011 Numads Technologies Pvt. Ltd. All rights reserved.
//

#import "DatabaseManager.h"
#import "Employee.h"
static DatabaseManager *dbManager = nil;

@implementation DatabaseManager
@synthesize database = database_;

+ (DatabaseManager*) sharedDatabaseManager
{
	@synchronized(self)
	{
		if ( nil == dbManager )
		{
			dbManager = [[self alloc] init] ;
		}
	}	
	return dbManager;
}

+ (id) allocWithZone: (NSZone *) inZone
{
    @synchronized(self) 
	{
        if ( dbManager == nil ) 
		{
			dbManager = [super allocWithZone: inZone];
            return dbManager;  // assignment and return on first allocation
        }
    }
    return nil; //on subsequent allocation attempts return nil
}

- (id) copyWithZone: (NSZone *) inZone
{
    return self;
}


-(id)init
{
	self = [super init];
	if (self)
	{
		BOOL success;
		NSFileManager *fileManager = [NSFileManager defaultManager];
		NSError *error;
		NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
		NSString *documentsDirectory = [paths objectAtIndex:0];
		NSString *writablePath = [documentsDirectory stringByAppendingPathComponent:@"examsdb.db"];
		success = [fileManager fileExistsAtPath:writablePath];
		if (!success) 
		{
			NSString *bundle = [[NSBundle mainBundle] pathForResource:@"examsdb" ofType:@"db"];
            NSLog(@"%@",bundle);
			
			success = [fileManager copyItemAtPath:bundle toPath:writablePath error:&error];
			if(!success)
			{
				NSLog(@"Error:%@",error);
			}
		}
		
		[self setDatabase:[FMDatabase databaseWithPath:writablePath]];
		
		if (![[self database]open])
		{
			NSLog(@"Could not open");
            UIAlertView *av1 = [[UIAlertView alloc] initWithTitle:@"DB not open" message:@"Some issue with DB" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [av1 show];
		}
		else {
			NSLog(@"DB opened");
		}
	}
	return self;
}


-(void)insertDetails:(Employee *)emp
{
    NSLog(@"%@",emp.questions);
    NSLog(@"%@",emp.option5);
    NSLog(@"%@",emp.option4);
    NSLog(@"%@",emp.option3);
    NSLog(@"%@",emp.option2);
    NSLog(@"%@",emp.option1);
    NSLog(@"%@",emp.option0);



    
    [[self database] executeUpdate:@"insert into questionstable(questions, option0,option1,option2,option3,option4,option5) values(?,?,?,?,?,?,?)",emp.questions,emp.option0,emp.option1,emp.option2,emp.option3,emp.option4,emp.option5];
  //  UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"Added to db" message:@"Success" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
    //[av show];
    NSLog(@"%@",emp);
}

-(NSMutableArray *)getDetails
{
    
    
    NSString *queryStr = [NSString stringWithFormat:@"Select * FROM mchoicetb  "];
    FMResultSet *rs = [[self database] executeQuery:queryStr];
    NSMutableArray *answers= [NSMutableArray new];
    
    while ([rs next]) {
        Employee *person = [[Employee alloc] init];
        person.chapter_id = [rs stringForColumn:@"mcchapterid"];
        [answers addObject:person];
    }
    
    return answers;
    


    
    
}
-(NSMutableArray *)getQuestions:(NSString *)chapterName
{
    NSString * chapterId = [NSString stringWithFormat:chapterName];
    
    NSString *queryStr = [NSString stringWithFormat:@"Select mcquestion_id FROM mchoicetb where mcchapterid='%@'",chapterId];
    FMResultSet *rs = [[self database] executeQuery:queryStr];
    NSMutableArray *answers= [NSMutableArray new];
    
    while ([rs next]) {
        Employee *person1 = [[Employee alloc] init];
        person1.q_id = [rs intForColumn:@"mcquestion_id"];
        [answers addObject:person1];
    }
    
    return answers;
    
    
    
    
    
}

-(NSString *)getQuestionsDatabase:(NSNumber * )quest
{
    int q_id = [quest integerValue];
    NSString *queryStr1 = [NSString stringWithFormat:@"Select * FROM mchoicetb where mcquestion_id=%i",q_id];
    FMResultSet *rs1 = [[self database] executeQuery:queryStr1];
    NSMutableArray *answers= [NSMutableArray new];
    
    while ([rs1 next]) {
        Employee *person = [[Employee alloc] init];
        person.strQuestion = [rs1 stringForColumn:@"mcquestion"];
        person.option0 = [rs1 stringForColumn:@"mcoption1"];
        person.option1 = [rs1 stringForColumn:@"mcoption2"];
        person.option2 = [rs1 stringForColumn:@"mcoption3"];
        person.option3= [rs1 stringForColumn:@"mcoption4"];
        person.option4= [rs1 stringForColumn:@"mcoption5"];
        person.option5= [rs1 stringForColumn:@"mcoption6"];



        [answers addObject:person];
    }
    
    return answers;
    

    
}


@end
