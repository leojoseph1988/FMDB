//
//  DatabaseManager.h
//  Contacts
//
//  Created by Muralitharan on 10/11/11.
//  Copyright 2011 Numads Technologies Pvt. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "Employee.h"
#import <AddressBook/AddressBook.h>
//@protocol
@interface DatabaseManager : NSObject {
	FMDatabase *database_;
}
@property(nonatomic,retain) FMDatabase *database;
+(DatabaseManager *)sharedDatabaseManager;

-(void)insertDetails:(Employee *)emp;
-(NSMutableArray *)getDetails;
-(NSMutableArray *)getQuestions:(NSString *)chapterName;
-(NSMutableArray *)getQuestionsDatabase:(NSNumber * )quest;

@end
